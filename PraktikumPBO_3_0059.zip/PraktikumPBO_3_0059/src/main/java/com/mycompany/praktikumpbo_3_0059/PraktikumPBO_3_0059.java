/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktikumpbo_3_0059;

/**
 *
 * @author acer
 */
public class PraktikumPBO_3_0059 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
