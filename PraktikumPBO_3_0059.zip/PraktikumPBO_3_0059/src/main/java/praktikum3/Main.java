/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum3;

/**
 *
 * @author acer
 */
public class Main {
    
    public static void main(String[]args) {

            Hewan kucing = new Hewan("Kucing", 3);
            
            System.out.println("=== Data Kucing ===");
            
            kucing.info();
            kucing.suara();
            
            System.out.println();
            
            Hewan anjing = new Hewan("Anjing",4);
            
            System.out.println("=== Data Anjing===");
            anjing.info();
            anjing.berlari();
            
    }
    
}

